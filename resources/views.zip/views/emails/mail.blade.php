Ticket Subject : {{$params['subject']}}
Ticket Summary : {{$params['ticket_summary']}}

