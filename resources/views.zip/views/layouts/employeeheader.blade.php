<!doctype html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://getbootstrap.com/docs/5.3/assets/css/docs.css" rel="stylesheet">
    <title>Aquachieme Support</title>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/js/bootstrap.bundle.min.js"></script>
  </head>
  <body>
    
    {{-- <nav class="nav flex-column">
      <div class="container-fluid">
        <ul class="nav nav-pills">
        <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="employeformation">Employee Info</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" href="">Employee HR INformation</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Personal Info</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Family Info</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Previous EMployement</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Bank Info</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Attachements</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Bank Info</a>
          </li>

          <li class="nav-item">
            <a class="nav-link active" aria-current="page" href="#">Salary Structure</a>
          </li>
        </ul>
      </div>
    </nav> --}}

  </body>
</html>